@extends('layouts.admin')
@section('content')
    <main id="js-page-content" role="main" class="page-content">
        <div class="subheader">
            <h1 class="subheader-title">
                <i class='subheader-icon fal fa-table'></i> Space Dashboard
            </h1>
        </div>
        <div class="row">
          <div class="col-sm-6 col-xl-6">
              <div class="p-3 bg-success-300 rounded overflow-hidden position-relative text-white mb-g">
                  <div class="">
                      <h3 class="display-4 d-block l-h-n m-0 fw-500">
                          {{ $open->count() }}
                          <small class="m-0 l-h-n">OPEN 
                            {{-- <b style="font-weight: 900">ROOM</b> --}}
                          </small>
                      </h3>
                  </div>
                  <i class="fal fa-table position-absolute pos-right pos-bottom opacity-15 mb-n1 mr-n1" style="font-size:6rem"></i>
              </div>
          </div>
          <div class="col-sm-6 col-xl-6">
              <div class="p-3 bg-danger-300 rounded overflow-hidden position-relative text-white mb-g">
                  <div class="">
                      <h3 class="display-4 d-block l-h-n m-0 fw-500">
                          {{ $closed->count() }}
                          <small class="m-0 l-h-n">CLOSED 
                            {{-- <b style="font-weight: 900">ROOM</b> --}}
                          </small>
                      </h3>
                  </div>
                  <i class="fal fa-table position-absolute pos-right pos-bottom opacity-15 mb-n1 mr-n1" style="font-size:6rem"></i>
              </div>
          </div>
          <div class="col-md-12 mb-4 d-flex">
            <div class="card flex-fill">
                <div class="card-header"><i class="fal fa-burn"></i> Room Type by Block</div>
                <div class="card-body">
                  <canvas id="groupChart" style="height: 400px"></canvas>
                </div>
            </div>
          </div>
          <div class="col-md-6 mb-4 d-flex">
            <div class="card flex-fill">
                <div class="card-header"><i class="fal fa-burn"></i> Room Type</div>
                <div class="card-body">
                  <canvas id="pieChart"></canvas>
                </div>
            </div>
          </div>
          <div class="col-md-6 mb-4 d-flex">
            <div class="card flex-fill">
                <div class="card-header"><i class="fal fa-burn"></i> Open / Closed Room</div>
                <div class="card-body">
                  <canvas id="horizontal-stacker-bar-chart"></canvas>
                </div>
            </div>
          </div>
          <div class="col-md-12 mb-4 d-flex">
            <div class="card flex-fill">
                <div class="card-header"><i class="fal fa-burn"></i> Summary</div>
                <div class="card-body">
                  <form method="get" id="department-form">
                    <div class="row">
                      <div class="col-md-4">
                        <p>Block</p>
                        <select class="form-control select" name="block_id" onchange="document.getElementById('department-form').submit()">
                          <option disabled selected>Select Block</option>
                          <option value="All" {{ 'All' == $selected_block ? 'selected' : '' }}>All</option>
                          @foreach ($all_block as $blocks)
                              <option value="{{ $blocks->id }}" {{ $blocks->id == $selected_block ? 'selected' : '' }}>{{ $blocks->name }}</option>
                          @endforeach
                        </select>
                      </div>
                      <div class="col-md-4">
                        <p>Status</p>
                        <select class="form-control select" name="status_id" onchange="document.getElementById('department-form').submit()">
                          <option value="">Select Status</option>
                          <option value="All" {{ 'All' == $selected_status ? 'selected' : '' }}>All</option>
                          <option value="1" {{ 1 == $selected_status ? 'selected' : '' }}>Opened</option>
                          <option value="2" {{ 2 == $selected_status ? 'selected' : '' }}>Closed</option>
                        </select>
                      </div>
                    </div>
                  </form>

                  @if($block != null)
                  <table class="table table-bordered mt-2 text-center">
                    <tr class="text-center bg-highlight font-weight-bold">
                      <td>Block</td>
                      <td>Room Type</td>
                      <td>Floor</td>
                      <td>Opened</td>
                      <td>Closed</td>
                    </tr>
                    <?php $total_opened = $total_closed = 0; ?>
                    @foreach($block as $blocks)
                      @foreach($blocks->facilityRooms->groupby(['room_id']) as $room)
                        <tr>
                          <td rowspan="{{ $room->groupby('floor')->count() + 1 }}">{{ $blocks->name }}</td>
                          <td rowspan="{{ $room->groupby('floor')->count() + 1 }}">{{ $room->first()->facilityRoomType->name }}</td>
                        </tr>
                        @foreach($room->groupby('floor') as $room_floor)
                        <?php
                          $room_opened = $room_floor->where('status_id','1')->count();
                          $room_closed = $room_floor->where('status_id','2')->count();
                          $total_opened += $room_opened;
                          $total_closed += $room_closed;
                        ?>
                        <tr>
                          <td>{{ $room_floor->first()->floor }}</td>
                          <td>{{ $room_opened }}</td>
                          <td>{{ $room_closed }}</td>
                        </tr>
                        @endforeach
                      @endforeach
                    @endforeach
                    <tr class="text-center font-weight-bold">
                      <td colspan="3">Total Open & Closed</td>
                      <td>{{ $total_opened }}</td>
                      <td>{{ $total_closed }}</td>
                    </tr>
                    <tr class="text-center font-weight-bold">
                      <td colspan="3">Overall</td>
                      <td colspan="2">{{ $total_opened + $total_closed }}</td>
                    </tr>
                  </table>
                  @endif
                </div>
            </div>
          </div>
        </div>
    </main>
@endsection
@section('script')
<script>
  $('.select').select2();
  var pie_chart = document.getElementById('pieChart').getContext('2d');
  var myChart = new Chart(pie_chart, {
    type: 'pie',
    data: {
      labels: @json($data['labels']),
      datasets: [{
          data: @json($data['data']),
          backgroundColor: [
              'rgba(224, 208, 245)',
              'rgba(252, 228, 186)',
              'rgba(253, 241, 230)',
              'rgba(247, 218, 232)',
              'rgba(183, 202, 180)',
          ],
      }]
    },
  });

  var ctx = document.getElementById("horizontal-stacker-bar-chart").getContext('2d');
  var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: [
          "Opened",
          "Closed",
        ],
        datasets: [
          {
            label: 'Block A',
            backgroundColor: "#9DBBE3",
            data: [3,3],
          },
          {
            label: 'Block B',
            backgroundColor: "#BFE3DF",
            data: [3,3], 
          },
          {
            label: 'Block C',
            backgroundColor: "#FFF5CC",
            data: [3,0], 
          },
          {
            label: 'Block D',
            backgroundColor: "#FFD9BD",
            data: [6,3], 
          },
          {
            label: 'Block E',
            backgroundColor: "#EE9D94",
            data: [0,0], 
          },
        ]
    },

    options: {
      scales: {
          xAxes: [{
                stacked: true,
          }],
          yAxes: [{
                stacked: true
          }]
      },
      legend: {
          display: false,
      },
    }
  });		
  
  var barChartData = {
    labels: [
      "Block A",
      "Block B",
      "Block C",
      "Block D",
      "Block E",
    ],
    datasets: [
      {
        label: "Toilet",
        backgroundColor: "#F7F0D7",
        data: [6, 6, 3, 9, 0]
      },
      // {
      //   label: "Classroom",
      //   backgroundColor: "#889ECE",
      //   data: [3, 5, 6, 7, 3]
      // },
      // {
      //   label: "Dewan",
      //   backgroundColor: "#C6DFB9",
      //   data: [4, 7, 3, 6, 10]
      // },
      // {
      //   label: "Lab",
      //   backgroundColor: "#F6DDC5",
      //   data: [2, 5, 3, 1, 4]
      // }
    ]
  };

  var chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
      position: "top"
    },
    title: {
      display: true,
      text: "Room Type by Block"
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true
        }
      }]
    }
  }

  window.onload = function() {
    var group_chart = document.getElementById("groupChart").getContext("2d");
    window.myBar = new Chart(group_chart, {
      type: "bar",
      data: barChartData,
      options: chartOptions
    });
  };


</script>
@endsection
